README.txt

Dependencies Required:

library(igraph)
library(xlsx)
library(plyr)
library(car)
library(dplyr)
library(data.table)
library(ggplot2)
library(reshape)
library(corpcor)
library(corrplot)
library(ggdendro)
library(knitr)
library(dendextend)
library(visNetwork)